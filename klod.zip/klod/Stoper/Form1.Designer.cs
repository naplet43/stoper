namespace Stoper
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblTime;
        private Button btnStart;
        private Button btnStop;
        private Button btnReset;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTime = new Label();
            this.btnStart = new Button();
            this.btnStop = new Button();
            this.btnReset = new Button();
            this.SuspendLayout();

            // --- lblTime ---
            this.lblTime.Font = new System.Drawing.Font("Consolas", 48F, System.Drawing.FontStyle.Bold);
            this.lblTime.ForeColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.lblTime.Location = new System.Drawing.Point(20, 30);
            this.lblTime.Size = new System.Drawing.Size(540, 80);
            this.lblTime.Text = "00:00:00.00";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // --- btnStart ---
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(76, 175, 80);
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.FlatStyle = FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(20, 130);
            this.btnStart.Size = new System.Drawing.Size(170, 55);
            this.btnStart.Text = "▶  Start";
            this.btnStart.Cursor = Cursors.Hand;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);

            // --- btnStop ---
            this.btnStop.BackColor = System.Drawing.Color.FromArgb(244, 67, 54);
            this.btnStop.FlatAppearance.BorderSize = 0;
            this.btnStop.FlatStyle = FlatStyle.Flat;
            this.btnStop.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Location = new System.Drawing.Point(200, 130);
            this.btnStop.Size = new System.Drawing.Size(170, 55);
            this.btnStop.Text = "⏹  Stop";
            this.btnStop.Cursor = Cursors.Hand;
            this.btnStop.Enabled = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);

            // --- btnReset ---
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(96, 125, 139);
            this.btnReset.FlatAppearance.BorderSize = 0;
            this.btnReset.FlatStyle = FlatStyle.Flat;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Location = new System.Drawing.Point(380, 130);
            this.btnReset.Size = new System.Drawing.Size(170, 55);
            this.btnReset.Text = "⟳  Reset";
            this.btnReset.Cursor = Cursors.Hand;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);

            // --- Form1 ---
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.ClientSize = new System.Drawing.Size(574, 210);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnReset);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Stoper";
            this.ResumeLayout(false);
        }
    }
}
