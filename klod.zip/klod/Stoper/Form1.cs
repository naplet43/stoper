using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Stoper
{
    public partial class Form1 : Form
    {
        private readonly Stopwatch _stopwatch = new Stopwatch();
        private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        public Form1()
        {
            InitializeComponent();

            _timer.Interval = 10; // update every 10ms
            _timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            UpdateDisplay();
        }

        private void UpdateDisplay()
        {
            TimeSpan ts = _stopwatch.Elapsed;
            lblTime.Text = string.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            _stopwatch.Start();
            _timer.Start();
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _stopwatch.Stop();
            _timer.Stop();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _stopwatch.Reset();
            _timer.Stop();
            UpdateDisplay();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }
    }
}
